<?php

return [
    'project_id' => env('GOOGLE_CLOUD_PROJECT_ID'),
    'storage_bucket' => env('GOOGLE_CLOUD_STORAGE_BUCKET'),
];