<?php

namespace App\Http\Controllers;

use App\Models\Driver;
use App\Models\Order;
use App\Models\Route;
use App\Models\Stops;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Exception;

class RouteController extends Controller
{
    public function list(Request $request)
    {
        $data = DB::select("SELECT routes.*, SUM(JSON_EXTRACT(data, '$[*].fallido')) fallidos, SUM(JSON_EXTRACT(data, '$[*].entregado')) entregados from routes GROUP BY id;");
        foreach ($data as $item) {
            $item->data = json_decode($item->data);
            $item->driver = json_decode($item->driver);
        }

        return response()->json($data);
    }

    public function asignedDriver(Request $request){

        try {
            Route::where("id", $request["id"])->update(
                [
                    "driver" => json_encode($request["driver"])
                ]
            );

            $route = Route::where("id", $request["id"])->first();

            $stop = new StopController();

            $stop->add($route, $request["reasign_driver"]);

            if($request["reasign_driver"] == false){
                return response()->json(["msg" => "El conductor ha sido asignado de forma exitosa.", "ok" => true], 200);
            }else{
                return response()->json(["msg" => "La reasignación del conductor ha sido de forma exitosa.", "ok" => true], 200);
            }
        } catch (Exception $e) {
            return response()->json(["msg" => $e->getMessage(), "ok" => false], 400);
        }
    }
    public function getRoute($id)
    {
        $data = Route::find($id);
        $data->driver = json_decode($data->driver);
        $data->data = json_decode($data->data);
        $data->packages = count($data->data);
        $data->points = count($data->data);

        $data->driver = Driver::find($data->driver->id);

        foreach ($data->data as $item) {
            $order = Order::select("contact", "identification","phone", "email")->where("id", $item->order_id)->first();
            // $stop = Stops::select("")->where("orden_id", $item->order_id)->first();
            $item->order = $order;
        }

        return response()->json($data, 200);
    }
}
